#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ArraySorter.h"

int* GenArr(int count);
void EvanSort(int* arr, int n);