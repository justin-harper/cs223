#include <iostream>
#include <stdio.h>
#include "HW2BST.h"

void MenuMode();
void ProcessLine(HW2BST& tree, char* line);